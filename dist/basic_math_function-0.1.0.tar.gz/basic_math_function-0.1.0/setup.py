from setuptools import setup

setup(
   name='basic_math_function',
   version='0.1.0',
   packages=['basic_math_function'],
   description='This is Basic Math Function Test',
   install_requires=[
       "requests",
   ]
)